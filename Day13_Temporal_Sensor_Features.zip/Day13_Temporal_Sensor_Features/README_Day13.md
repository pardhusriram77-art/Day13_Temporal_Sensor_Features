# Day 13 — Temporal & Sensor Features

## Deliverables
- `engineered_features_v1.csv`: timestamp-valid dataset with raw features, target, split labels, calendar features, lags, rolling statistics, and exploratory cross-feature aggregates.
- `raw_vs_engineered_comparison.csv`: row and feature counts plus missingness comparison by split.
- `feature_definitions.csv`: definitions, availability assumptions, and risks for engineered features.
- `feature_leakage_audit.csv`: checks for target leakage, future leakage, and split-boundary leakage.
- `water_potability_temporal_raw_copy.csv`: preserved raw input copy.
- `Day13_Feature_Engineering.ipynb`: reproducible notebook.

## Feature design
- Calendar features: hour, day of week, month, day of year.
- Lag features: previous row and three rows earlier for each of eight numeric features.
- Rolling features: mean and standard deviation of prior up-to-three rows, excluding current row.
- Cross-feature aggregates: row-wise mean and standard deviation across the eight features.

## Important assumptions and limitations
1. Timestamp parse failures are excluded from the engineered dataset; the raw copy preserves them.
2. The split is chronological (approximately 70/15/15 by unique timestamp) and identical timestamps stay in the same split.
3. Lags and rolling features are computed within each split to avoid crossing split boundaries. Therefore the earliest records of each split have missing lag/rolling values.
4. Rolling features use prior rows, not fixed-duration time windows; irregular synthetic timestamps mean these are not equivalent to 3-hour rolling windows.
5. The target `Potability` is never used to create features.
6. Cross-feature row-wise mean and standard deviation combine features with different units/scales and are only exploratory; do not interpret as physical measures.
7. The timestamps were synthetically generated from a static water-potability dataset. Temporal/calendar features do not represent genuine observed environmental patterns.
8. Do not freeze these features as final predictive inputs until mentor review and comparison on a valid evaluation design.

## Run
```bash
pip install pandas numpy matplotlib
jupyter notebook Day13_Feature_Engineering.ipynb
```
